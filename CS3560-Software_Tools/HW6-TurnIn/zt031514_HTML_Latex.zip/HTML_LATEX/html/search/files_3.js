var searchData=
[
  ['othello_2eh',['othello.h',['../othello_8h.html',1,'']]]
];
