var searchData=
[
  ['is_5fblank',['is_blank',['../classpiece.html#af8e5afd9e1eb6b367c7da643c94c7113',1,'piece']]]
];
