var searchData=
[
  ['main_2ecc',['main.cc',['../main_8cc.html',1,'']]],
  ['make_5fmove',['make_move',['../classmain__savitch__14_1_1Othello.html#a1066b280efa5cb41039585669282fe06',1,'main_savitch_14::Othello']]]
];
